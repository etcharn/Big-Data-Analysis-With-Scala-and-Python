from mrjob.compat import jobconf_from_env
from mrjob.job import MRJob
import math
import re


class TermWeightsComputation(MRJob):


    def mapper_init(self):
        self.Dict = {}

    def mapper(self, _, line):

        date, termString = line.strip().split(",")
        # extract year
        year = date[0:4]
        # extract term
        terms = termString.strip().split(" ")
        for term in terms:
            if len(term):
                key = term + "," + year
                self.Dict[key] = self.Dict.get(key, 0) + 1

    def mapper_final(self):
        for key in self.Dict:
            term, year = key.split(",")
            yield (term, (year, self.Dict[key]))

    def reducer(self, key, values):
        [term, yearFreq_dict] = key, dict(values)
        year_countAll = int(jobconf_from_env('myjob.settings.years', 3))
        yearWeightString = ""
        sortedYearFreq = sorted(yearFreq_dict)
        for year in sortedYearFreq:
            # number of key = # of years having term
            year_occur = len(yearFreq_dict)
            # use year as a key to get frequency
            TF = yearFreq_dict[year]
            IDF = math.log10(year_countAll / year_occur)
            weight = TF * IDF
            yearWeightString = yearWeightString + year + ',' + str(weight)
            # if i is last index, we don't print
            if year != sortedYearFreq[-1]:
                yearWeightString = yearWeightString + ';'
            else:
                break

        yield term, yearWeightString


if __name__ == '__main__':
    TermWeightsComputation.run()


