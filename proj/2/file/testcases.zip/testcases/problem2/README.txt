We provide you 7 test cases.

Our marking will be based on a larger graph, for example more than 500 nodes. Hence you need to think how to improve the efficiency of your code on such graph (or even larger one)