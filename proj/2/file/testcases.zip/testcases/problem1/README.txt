The test case is extracted from abc news.

The output is the top 10 results.
You can use these commands to test your code:
$ hdfs dfs -mkdir p1
$ hdfs dfs -rm -r out1
$ hdfs dfs -put in/*.txt p1
$ spark-submit --class "comp9313.proj2.Problem1" target/scala-2.12/problem-1_2.12-1.0.jar 10 p1/stopwords.txt p1/prob1.txt out1
$ rm -r out1
$ hdfs dfs -get out1